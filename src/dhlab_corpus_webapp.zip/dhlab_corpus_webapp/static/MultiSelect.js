const dropdownToggle = document.querySelector('.dropdown-toggle');
const dropdownMenu = document.querySelector('.dropdown');
const checkboxes = document.querySelectorAll('.checkbox');
const selectedTagsContainer = document.getElementById('selectedTags');
const hiddenFieldsContainer = document.getElementById('hidden-fields-container');
const langContainer = document.getElementById('langContainer');  // New container for the lang attribute string

function updateTags() {
    const selectedTags = [];

    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            selectedTags.push(checkbox.value);
        }
    });

    selectedTagsContainer.innerHTML = '';

    selectedTags.forEach(tag => {
        const tagElement = document.createElement('div');
        tagElement.classList.add('tag');
        tagElement.textContent = tag;

        const deleteSpan = document.createElement('span');
        deleteSpan.textContent = '×';
        deleteSpan.addEventListener('click', function () {
            removeTag(tag);
        });

        tagElement.appendChild(deleteSpan);
        selectedTagsContainer.appendChild(tagElement);

        addHiddenInput(tag);
    });

    // Update lang attribute string
    updateLangString(selectedTags);
}

function updateLangString(tags) {
    const langString = tags.join(' ');  // Join the selected tags into a string
    if (langContainer) {
        langContainer.setAttribute('lang', langString);  // Set the lang attribute on the container
    }
}

function removeTag(tag) {
    const checkbox = Array.from(checkboxes).find(checkbox => checkbox.value === tag);
    if (checkbox) {
        checkbox.checked = false; 
    }
    updateTags(); 
}

function addHiddenInput(tagValue) {
    // Check if the hidden input for this tag already exists
    let existingInput = document.getElementById('hidden-' + tagValue);
    if (!existingInput) {
        const hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = 'languages';  // The name of the field to be accessed in Flask
        hiddenInput.value = tagValue;
        hiddenInput.id = 'hidden-' + tagValue;
        hiddenFieldsContainer.appendChild(hiddenInput); // Append it to the container
    }
}

// Toggle on click
dropdownToggle.addEventListener('click', function (event) {
    event.stopPropagation(); 
    dropdownMenu.classList.toggle('open');
});

checkboxes.forEach(checkbox => {
    checkbox.addEventListener('change', updateTags);
});

document.addEventListener('click', function (event) {
    if (!dropdownMenu.contains(event.target) && !dropdownToggle.contains(event.target)) {
        dropdownMenu.classList.remove('open'); // Close the dropdown
    }
});

updateTags(); // Initialize the tags container when the page loads