from functools import lru_cache
from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
import io
import dhlab as dh
from dataclasses import dataclass, asdict
import urllib.parse
import html

#Dataclass for CorpusMetadata
"""Fra Marie:  urlencode er en funksjon som returnerer en streng på formatet doc_type_selection=digibok&author=Ibsen&title=&num_docs=2000
Du kan bruke denne for å returnere URL-er for å laste ned JSON- eller Excel-data for en gitt korpusdefinisjon. 
Det som er fint er at siden vi har satt frozen=True så kan vi bruke instanser av denne dataklassen i en cachet funksjon."""
@dataclass(frozen=True)
class CorpusMetadata:
    doc_type_selection: str | None = None
    language: str | None = None
    author: str | None = None
    title: str | None = None
    words_or_phrases: str | None = None
    key_words: str | None = None
    dewey: str | None = None
    from_year: str | None = None
    to_year: str | None = None
    search_type: str | None = None
    num_docs: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, str]) -> "CorpusMetadata":
        return cls(
            doc_type_selection=data.get("doc_type_selection"),
            language=data.get("lang_selection"),
            author=data.get("author"),
            title=data.get("title"),
            words_or_phrases=data.get("words_or_phrases"),
            key_words=data.get("key_words"),
            dewey=data.get("dewey"),
            from_year=data.get("from_year"),
            to_year=data.get("to_year"),
            search_type=data.get("search_type"),
            num_docs=data.get("num_docs"),
        )

    def urlencode(self) -> str:
        data = {k: v for k, v in asdict(self).items() if v is not None}
        return html.escape(urllib.parse.urlencode(data))

@lru_cache(maxsize=128)  # Hva er en god verdi her?
def fetch_corpus_from_metadata(metadata: CorpusMetadata):
    #Lag korpus med metadataen
    corpus = dh.Corpus(
        doctype=metadata.doc_type_selection, 
        author=metadata.author, 
        freetext=None, 
        fulltext=metadata.words_or_phrases, 
        from_year=metadata.from_year, 
        to_year=metadata.to_year,
        from_timestamp=None, 
        title=metadata.title, 
        ddk=metadata.dewey, 
        subject=metadata.key_words, 
        lang=metadata.language, 
        limit=metadata.num_docs, 
        order_by=metadata.search_type, 
        allow_duplicates=False
    )

    #Select the relevant columns from the dataframe
    corpus_selected = corpus[['dhlabid', 'authors', 'title', 'city', 'timestamp', 'year', 'publisher', 'ddc', 'subjects', 'langs']]
    df_from_corpus = corpus_selected.frame

    #Return the data as a list of dictionaries
    return df_from_corpus.to_dict('records')

# Create Flask app
def create_app() -> Flask:
    app = Flask(__name__)

    @app.route("/")
    def index() -> str:
        return render_template("index_base.html")

    @app.route('/submit-form', methods=['GET','POST']) #la til GET fordi jeg håpet at det ville fikse refresh-problemet
    def make_corpus() -> str:
        # Extract form data from the request
        form_data = {
            "doctype": request.form.get('doc_type_selection'),
            "language": request.form.get('language'),
            "author": request.form.get('author'),
            "title": request.form.get('title'),
            "words_or_phrases": request.form.get('words_or_phrases'),
            "key_words": request.form.get('key_words'),
            "dewey": request.form.get('dewey'),
            "from_year": request.form.get('from_year'),
            "to_year": request.form.get('to_year'),
            "search_type": request.form.get('search_type'),
            "num_docs": request.form.get('num_docs')
        }

        # Create a CorpusMetadata instance from the form data
        metadata = CorpusMetadata.from_dict(form_data)

        # Fetch the corpus data, with caching
        corpus_data = fetch_corpus_from_metadata(metadata)
        print("corpus_data!", corpus_data)

        # Return the corpus data as JSON
        return jsonify(corpus_data)

    """@app.route('/download-excel', methods=['GET'])
    def write_to_excel():
        # Use the same logic for fetching the data
        corpus_response = make_corpus()
        corpus_data = corpus_response.get_json()  # Convert JSON response to a list of dicts
        
        df = pd.DataFrame(corpus_data)
        
        # Create an in-memory Excel file
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False)
        
        # Set the buffer position to the beginning of the file
        output.seek(0)

        # Send the file as a response
        return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', as_attachment=True, download_name='output.xlsx')"""

    return app

# Instantiate and run the Flask app
app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
